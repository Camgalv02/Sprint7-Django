from django.contrib import admin

# Register your models here.

from .models import Movimientos

@admin.register(Movimientos)
class MovimientosAdmin(admin.ModelAdmin):
    list_display=('movimiento_id','numero_cuenta','tipo_operacion','monto','hora')