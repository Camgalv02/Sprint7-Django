from django import forms
from django.contrib.auth.forms import UserCreationForm
from clientes.models import Cliente
from django.contrib.auth.models import User

class FormularioRegistro(UserCreationForm):
    cliente = forms.ModelChoiceField(queryset=Cliente.objects.all(), required=True, widget=forms.Select)

    class Meta:
        model = User
        fields = ['username', 'password1', 'password2', 'cliente']

    def save(self, commit=True):
        user = super().save(commit=False)

        # Asocia el usuario al cliente seleccionado
        cliente = self.cleaned_data.get('cliente')
        cliente.user = user
        cliente.save()

        if commit:
            user.save()

        return user