from django.contrib import admin

# Register your models here.

from .models import Empleado

@admin.register(Empleado)
class EmpleadoAdmin(admin.ModelAdmin):
    list_display=('employee_id','employee_name','employee_surname')