from django.contrib import admin

# Register your models here.

from .models import Direcciones

@admin.register(Direcciones)
class DireccionesAdmin(admin.ModelAdmin):
    list_display=('direccion_id','employee_id','calle','pais')