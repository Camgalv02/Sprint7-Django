from django.db import models

# Create your models here.

from empleados.models import Empleado

class Direcciones(models.Model):
    direccion_id = models.AutoField(primary_key=True, blank=True)
    employee = models.ForeignKey(Empleado, models.DO_NOTHING, blank=True, null=True)
    calle = models.CharField(max_length=200, blank=True, null=True)
    ciudad = models.CharField(max_length=200, blank=True, null=True)
    pais = models.CharField(max_length=200, blank=True, null=True)
    codigo_postal = models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'direcciones'
