from django.contrib import admin

# Register your models here.

from .models import Sucursal

@admin.register(Sucursal)
class SucursalAdmin(admin.ModelAdmin):
    list_display=('branch_id','branch_number','branch_name')