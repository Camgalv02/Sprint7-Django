from django.db import models

# Create your models here.

from clientes.models import Cliente

class Tarjeta(models.Model):
    tarjeta_id = models.AutoField(primary_key=True, blank=True)
    customer = models.ForeignKey(Cliente, on_delete=models.CASCADE, blank=True, null=True)
    numero = models.TextField(unique=True, blank=True, null=True)
    marca = models.TextField(blank=True, null=True)
    cvv = models.TextField(blank=True, null=True)
    fecha_otorgamiento = models.DateField(blank=True, null=True)
    fecha_expiracion = models.DateField(blank=True, null=True)
    tipo = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tarjeta'