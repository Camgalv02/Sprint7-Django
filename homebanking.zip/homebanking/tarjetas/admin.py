from django.contrib import admin

# Register your models here.

from .models import Tarjeta

@admin.register(Tarjeta)
class TarjetaAdmin(admin.ModelAdmin):
    list_display=('tarjeta_id','customer_id','numero','marca','tipo')