from django.shortcuts import render

# Create your views here.

from .models import Cliente

def lista_clientes(request):
    clientes = Cliente.objects.all()

    nombre_cliente_filtro = request.GET.get('nombre_cliente','')
    
    if nombre_cliente_filtro:
        clientes= clientes.filter(customer_name__icontains=nombre_cliente_filtro)

    return render(request, 'clientes.html', {'clientes': clientes})

def detalle_cliente(request, cliente_id):
    cliente = Cliente.objects.get(pk=cliente_id)
    cuentas = cliente.cuenta_set.all() 
    tarjetas = cliente.tarjeta_set.all() 
    return render(request, 'detalle_cliente.html', {'cliente': cliente, 'cuentas': cuentas, 'tarjetas': tarjetas})