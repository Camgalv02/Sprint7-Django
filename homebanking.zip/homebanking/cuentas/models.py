from django.db import models
from clientes.models import Cliente
# Create your models here.

class Cuenta(models.Model):
    account_id = models.AutoField(primary_key=True)
    customer= models.ForeignKey(Cliente, on_delete=models.CASCADE)
    balance = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    iban = models.CharField(max_length=34) 
    tipo_cuenta = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'cuenta'