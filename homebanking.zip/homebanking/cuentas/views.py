from django.shortcuts import render, redirect
from .models import Cuenta
# Create your views here.

from .forms import CrearCuentaForm

def lista_cuentas(request):
    cuentas = Cuenta.objects.all()
    
    nombre_cliente_filtro = request.GET.get('nombre_cliente','')
    
    if nombre_cliente_filtro:
        clientes= clientes.filter(customer_name__icontains=nombre_cliente_filtro)

    return render(request, 'cuentas.html', {'cuentas': cuentas})

def crear_cuenta(request):
    if request.method == 'POST':
        form = CrearCuentaForm(request.POST)
        if form.is_valid():
            cuenta = form.save(commit=False)
            cuenta.usuario = request.user
            cuenta.save()
            return redirect('detalle_cuenta', cuenta_id=cuenta.pk)
    else:
        form = CrearCuentaForm()

    return render(request, 'crear_cuenta.html', {'form': form})

def detalle_cuenta(request, cuenta_id):
    cuenta = Cuenta.objects.get(account_id=cuenta_id)
    cuentas_del_cliente = Cuenta.objects.filter(customer=cuenta.customer)
    
    return render(request, 'detalle_cuenta.html', {'cuenta': cuenta, 'cuentas_del_cliente': cuentas_del_cliente})