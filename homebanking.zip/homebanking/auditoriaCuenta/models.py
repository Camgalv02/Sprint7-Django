from django.db import models

# Create your models here.

class AuditoriaCuenta(models.Model):
    auditoria_cuenta_id = models.AutoField(primary_key=True, blank=True)
    auditoria_cuenta_old_id = models.IntegerField(blank=True, null=True)
    auditoria_cuenta_new_id = models.IntegerField(blank=True, null=True)
    auditoria_cuenta_old_balance = models.FloatField(blank=True, null=True)
    auditoria_cuenta_new_balance = models.FloatField(blank=True, null=True)
    auditoria_cuenta_old_iban = models.TextField(blank=True, null=True)
    auditoria_cuenta_new_iban = models.TextField(blank=True, null=True)
    auditoria_cuenta_old_type = models.TextField(blank=True, null=True)
    auditoria_cuenta_new_type = models.TextField(blank=True, null=True)
    auditoria_cuenta_user_action = models.TextField(blank=True, null=True)
    auditoria_cuenta_created_at = models.TextField(blank=True, null=True)  # This field type is a guess.

    class Meta:
        managed = False
        db_table = 'auditoria_cuenta'