from django.contrib import admin

# Register your models here.

from .models import AuditoriaCuenta

@admin.register(AuditoriaCuenta)
class AuditoriaCuentaAdmin(admin.ModelAdmin):
    list_display=('auditoria_cuenta_id','auditoria_cuenta_old_id','auditoria_cuenta_new_id')