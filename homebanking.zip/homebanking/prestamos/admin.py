from django.contrib import admin

# Register your models here.

from .models import Prestamo

@admin.register(Prestamo)
class PrestamoAdmin(admin.ModelAdmin):
    list_display=('loan_id','loan_type','loan_total','customer_id')